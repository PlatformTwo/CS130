# CS130
Group project for CS130 - Software Engineering

Website to gather academic resources for UCLA students as well as facilitate collaboration amongst students.

Team Members: Wilsen Kosasih, Vincent Nguyen, Sepideh Hoshemzadeh, Andrew Lin, Kirk Zhang, Lingfeng Yang
